Hate Crime Victimization, 2005–2019 NCJ 300954		
		
This zip archive contains tables in individual .csv spreadsheets		
from Hate Crime Victimization, 2005–2019 NCJ 300954		
The full report including text and graphics in .pdf format is available at		
https://bjs.ojp.gov/library/publications/hate-crime-victimization-2005-2019
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to 		
https://bjs.ojp.gov/library/publications/list?series_filter=Hate%20Crime		
		
Filename	Table titles	
hcv0519t01.csv	Table 1. Hate crime victimizations, by type of crime, 2005–2019	
hcv0519t02.csv	Table 2. Hate crime victimizations, by type of crime and reporting to police, 2015–19	
hcv0519t03.csv	Table 3. Hate crime victimizations, by type of crime and bias motivation, 2015–19	
hcv0519t04.csv	Table 4. Violent hate crime victimizations, by victim and population characteristics, 2010–19	
hcv0519t05.csv	Table 5. Violent hate crime incidents, by demographic characteristics of victims, offenders, and population, 2015–19	
hcv0519t06.csv	Table 6. Violent hate and nonhate crime incidents, by offender characteristics reported by victims, 2015–19	
		
		Figures	
hcv0519f01.csv	Figure 1. Rates of violent hate crime victimizations per 1,000 persons age 12 or older, 2005–2019	
hcv0519f02.csv	Figure 2. Violent hate crime victimizations, by reporting to police and most important reason for not reporting, 2015–19	
hcv0519f03.csv	Figure 3. Percent of violent hate crime victimizations, by select characteristics of victims, bias motivations, and population, 2010–19	
hcv0519f04.csv	Figure 4. Classifying hate crimes in the National Crime Victimization Survey	
		
		Appendix tables	
hcv0519at01.csv	Appendix Table 1. Average annual hate crimes reported to the National Crime Victimization Survey and the Uniform Crime Reporting Program, 2010–19	
hcv0519at02.csv	Appendix Table 2. Estimates and standard errors for figure 1: Rates of violent hate crime victimizations per 1,000 persons age 12 or older, 2005–2019	
hcv0519at03.csv	Appendix Table 3. Estimates and standard errors for figure 2: Violent hate crime victimizations, by reporting to police and most important reason for not reporting, 2015–19	
hcv0519at04.csv	Appendix Table 4. Estimates and standard errors for figure 3: Percent of violent hate crime victimizations, by select characteristics of victims, bias motivations, and population, 2010–19	
hcv0519at05.csv	Appendix Table 5. Standard errors for table 1: Hate crime victimizations, by type of crime, 2005–2019	
hcv0519at06.csv	Appendix Table 6. Standard errors for table 2: Hate crime victimizations, by type of crime and reporting to police, 2015–19	
hcv0519at07.csv	Appendix Table 7. Standard errors for table 3: Hate crime victimizations, by type of crime and bias motivation, 2015–19	
hcv0519at08.csv	Appendix Table 8. Standard errors for table 4: Violent hate crime victimizations, by victim and population characteristics, 2010–19	
hcv0519at09.csv	Appendix Table 9. Standard errors for table 5: Violent hate crime incidents, by demographic characteristics of victims, offenders, and population, 2015–19	
hcv0519at10.csv	Appendix Table 10. Standard errors for table 6: Violent hate and nonhate crime incidents, by offender characteristics reported by victims, 2015–19	
		
